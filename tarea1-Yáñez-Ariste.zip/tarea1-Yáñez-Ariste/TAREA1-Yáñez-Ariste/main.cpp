#include <iostream>
#include <string>
#include <fstream>

using namespace std;

struct Pieza
{
    char simbolo;
    int x, y;
};

struct Tablero {     
    Pieza *piezas_tablero;
    int cantidad_piezas;
};

/*
* bool jaqueDama(Tablero &tablero, int reyX, int reyY)
**
* Utilizamos un while para recorrer todo el tablero, encontrar las coordenadas de la reina, las cuales guardamos en 
*los parametros damaX y damaY, luego programamos el comportamiento de la dama y determinamos si pone en jaque al rey enemigo o no.
**
* Input:
* Tablero &tablero : Referencia al tablero de ajedrez.
* int reyX : Coordenada x del rey.
* int reyY : Coordenada y del rey.
**
* Returns:
* bool : En caso que devuelva true, es porque la dama pone en jaque al rey, en caso contrario, false.
**/

bool jaqueDama(Tablero &tablero, int reyX, int reyY) {
    int i = 0;
    while (i < 64) {
        if (tablero.piezas_tablero[i].simbolo == 'R') {
            int damaX = tablero.piezas_tablero[i].x;
            int damaY = tablero.piezas_tablero[i].y;
            if ((damaX == reyX) || (damaY == reyY) || (abs(damaX - reyX) == abs(damaY - reyY))) {
                return true;
            }   
        }
        i+=1;
    }

    return false;
}

/*
* bool jaquePeon(Tablero &tablero, int reyX, int reyY)
**
* Utilizamos un while para recorrer todo el tablero, encontrar las coordenadas de los peones, las cuales guardamos en 
*los parametros peonX y peonY, luego programamos el comportamiento del peon y determinamos si alguno pone en jaque al rey enemigo o no.
**
* Input:
* Tablero &tablero : Referencia al tablero de ajedrez.
* int reyX : Coordenada x del rey.
* int reyY : Coordenada y del rey.
**
* Returns:
* bool : En caso que devuelva true, es porque un peon pone en jaque al rey, en caso contrario, false.
**/

bool jaquePeon(Tablero &tablero, int reyX, int reyY) {
    int i = 0;
    while (i < 64) {
        if (tablero.piezas_tablero[i].simbolo == 'P') {
            int peonX = tablero.piezas_tablero[i].x;
            int peonY = tablero.piezas_tablero[i].y;
            if ((peonX == reyX + 1 && (peonY == reyY + 1 || peonY == reyY - 1)) || (peonX == reyX - 1 && (peonY == reyY + 1 || peonY == reyY - 1))) {
                return true;
            }
        }
        i += 1;
    }
    return false;
}

/*
* bool jaqueCaballo(Tablero &tablero, int reyX, int reyY)
**
* Utilizamos un while para recorrer todo el tablero, encontrar las coordenadas de los caballos, las cuales guardamos en 
*los parametros caballoX y caballoY, luego programamos el comportamiento del caballo y determinamos si alguno pone en jaque al rey enemigo o no.
**
* Input:
* Tablero &tablero : Referencia al tablero de ajedrez.
* int reyX : Coordenada x del rey.
* int reyY : Coordenada y del rey.
**
* Returns:
* bool : En caso que devuelva true, es porque un caballo pone en jaque al rey, en caso contrario, false.
**/

bool jaqueCaballo(Tablero &tablero, int reyX, int reyY) {
    int i = 0;
    while (i < 64) {
        if (tablero.piezas_tablero[i].simbolo == 'C') {
            int caballoX = tablero.piezas_tablero[i].x;
            int caballoY = tablero.piezas_tablero[i].y;
            if ((abs(caballoX - reyX) == 2 && abs(caballoY - reyY) == 1) || (abs(caballoX - reyX) == 1 && abs(caballoY - reyY) == 2)) {
                return true;
            }
        }
        i += 1;
    }

    return false;
}

/*
* bool jaqueAlfil(Tablero &tablero, int reyX, int reyY)
**
* Utilizamos un while para recorrer todo el tablero, encontrar las coordenadas de los Alfiles, las cuales guardamos en 
*los parametros AlfilX y AlfilY, luego programamos el comportamiento del Alfil y determinamos si alguno pone en jaque al rey enemigo o no.
**
* Input:
* Tablero &tablero : Referencia al tablero de ajedrez.
* int reyX : Coordenada x del rey.
* int reyY : Coordenada y del rey.
**
* Returns:
* bool : En caso que devuelva true, es porque un Alfil pone en jaque al rey, en caso contrario, false.
**/

bool jaqueAlfil(Tablero &tablero, int reyX, int reyY) {
    int i = 0;
    while (i < 64) {
        if (tablero.piezas_tablero[i].simbolo == 'A') {
            int alfilX = tablero.piezas_tablero[i].x;
            int alfilY = tablero.piezas_tablero[i].y;
            if (abs(alfilX - reyX) == abs(alfilY - reyY)) {
                return true;
            }
        }
        i += 1;
    }

    return false;
}

/*
* void liberarMemoria(Tablero &tablero)
**
* Liberamos la memoria asignada dinamicamente que no estamos utilizando del tablero usando delete, pues ya almacenamos
* la informacion que necesitabamos (especificamente de los arreglos).
**
* Input:
* Tablero &tablero : Referencia al tablero de ajedrez.
**
* Returns:
* void: No retorna nada, al ser void no se gastan bits en retornar algun valor
**/

void liberarMemoria(Tablero &tablero) {
    delete[] tablero.piezas_tablero;
}

/*
* bool jaqueRey(Tablero &tablero, int reyX, int reyY)
**
* Toma en cuenta todos los posibles jaques de las piezas aliadas, en esta misma funcion tambien implementamos el 
* comportamiento de la torre, pues fue el primer comportamiento que agregamos para hacer testeos de jaques. Por lo tanto
* los parametros fila_torre, columna_torre, fila_rey y columna_rey fueron los parametros utilizados
* para determinar si el rey estaba en jaque bajo la torre o no.
*
* La segunda parte de la funcion, donde se encuentran los if referenciando a las funciones anteriormente explicadas,
* determina si las otras piezas estan poniendo en jaque al rey o no.
**
* Input:
* Tablero &tablero : Referencia al tablero de ajedrez.
* int reyX : Coordenada x del rey.
* int reyY : Coordenada y del rey.
**
* Returns:
* bool : En caso que devuelva true, es porque el rey esta en jaque, en caso contrario, false.
**/

bool jaqueRey(Tablero &tablero,int reyX, int reyY) {
    bool torre1 = false;
    int fila_torre = -1;
    int columna_torre = -1;
    int fila_torre2 = -1;
    int columna_torre2 = -1;
    int fila_rey = -1;
    int columna_rey = -1;

    int i = 0;
    while (i < 64) {
        if (tablero.piezas_tablero[i].simbolo == 'T') {
            if (!torre1) {
                fila_torre = tablero.piezas_tablero[i].x;
                columna_torre = tablero.piezas_tablero[i].y;
                torre1 = true;
            }
            else {
                fila_torre2 = tablero.piezas_tablero[i].x;
                columna_torre2 = tablero.piezas_tablero[i].y;
            }
        }
        else if (tablero.piezas_tablero[i].simbolo == 'X') {
            fila_rey = tablero.piezas_tablero[i].x;
            columna_rey = tablero.piezas_tablero[i].y;
        }
        i += 1;
    }
    if (jaquePeon(tablero, reyX, reyY)) {
        return true;
        }
    
    if (fila_rey == fila_torre || fila_rey == fila_torre2 || columna_rey == columna_torre || columna_rey == columna_torre2) {
        return true;
    }
    if (jaqueAlfil(tablero, reyX, reyY)) {
        return true;
    
    }
    if (jaqueCaballo(tablero, reyX, reyY)) {
        return true;
    }
    if (jaqueDama(tablero, reyX, reyY)) {
        return true;
    }
    
    return false;
    
}
/*
* bool jaqueMate(Tablero &tablero, int reyX, int reyY)
**
* Determina si hay jaque mate en el tablero de ajedrez.
**
* Input:
* Tablero &tablero : Referencia al tablero de ajedrez.
* int reyX : Coordenada x del rey.
* int reyY : Coordenada y del rey.
**
* Returns:
* bool : Devuelve verdadero si hay jaque mate, de lo contrario, falso.
**/

bool jaqueMate(Tablero &tablero,int reyX, int reyY) {
    if ((!jaqueRey(tablero, reyX, reyY)))
        return false; 
    int i = 0;
    while (i < tablero.cantidad_piezas) {
        int original_x = tablero.piezas_tablero[0].x;
        int original_y = tablero.piezas_tablero[0].y;
        char pieza = tablero.piezas_tablero[i].simbolo;

        int j = 0;
        while (j < tablero.cantidad_piezas) {
            int original_x_mover = tablero.piezas_tablero[i].x;
            int original_y_mover = tablero.piezas_tablero[i].y;

            tablero.piezas_tablero[i].x = tablero.piezas_tablero[j].x;
            tablero.piezas_tablero[i].y = tablero.piezas_tablero[j].y;

            if (!jaqueRey(tablero, reyX, reyY)) {
                tablero.piezas_tablero[i].x = original_x_mover;
                tablero.piezas_tablero[i].y = original_y_mover;
                tablero.piezas_tablero[0].x = original_x;
                tablero.piezas_tablero[0].y = original_y;
                return false;
            }

            tablero.piezas_tablero[i].x = original_x_mover;
            tablero.piezas_tablero[i].y = original_y_mover;
            j += 1;
        }
        i += 1;
    }

    return true;
}

int main() {
    ifstream fp("tablero.txt");
    Tablero tablero;

    if (fp.is_open()) {
        fp >> tablero.cantidad_piezas;
        tablero.piezas_tablero = new Pieza[64]; 

        int piezas_leidas = 0;

        int fila = 0;
        while (fila < 8) {
            int columna = 0;
            string fila_actual;
            fp >> fila_actual;

            while (columna < 8) {
                char simbolo = fila_actual[columna];
                Pieza nueva_pieza;
                nueva_pieza.simbolo = simbolo;
                nueva_pieza.x = columna;
                nueva_pieza.y = fila;
                
                tablero.piezas_tablero[piezas_leidas++] = nueva_pieza;
                ++columna;
            }
            ++fila;
        }

        fp.close();
    } else {
        cout << "No se pudo abrir el archivo tablero.txt" << endl;
    }

    int reyX = -1;
    int reyY = -1;

    for (int i = 0; i < 64; i++)
    {
        if (tablero.piezas_tablero[i].simbolo == 'X')
        {
            reyX = tablero.piezas_tablero[i].x;
            reyY = tablero.piezas_tablero[i].y;
            break;
        }
    }
    
    if (jaqueMate(tablero, reyX,reyY))
    {
        cout << "Si" << endl;
    }
    else
    {
        cout << "No" << endl;
    }

    liberarMemoria(tablero);

    return 0;
}