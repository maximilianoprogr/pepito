Para compilar recomendamos utilizar linux junto a su terminal, usando el mismo compilador que usamos, g++.
Pasos a realizar

1)Abrir visual estudio code.
2)Abrir el archivo Tarea 1, y visualizar cada uno de sus archivos en Visual Studio
3)En el archivo llamado main, click derecho y abrir Open Containing Folder
4)Una vez en las carpetas de visual, abrir una terminal.
5)Ejecutar el archivo ejecutando los siguientes comando 
 
 g++ main.cpp -0 main

 ./main 
